import sys, os, json
from datetime import datetime, timedelta, time
from PySide6 import QtWidgets, QtGui, QtCore
import ctypes

# ------------------ Eventliste ------------------
koloss_events = {
    "Frostringen": [time(1,0), time(2,0), time(6,0), time(8,0), time(13,0), time(14,0), time(18,0), time(20,0)],
    "Karuma": [time(0,0), time(2,0), time(4,0), time(7,0), time(8,0), time(12,0), time(14,0), time(16,0),time(19,0), time(20,0)],
    "Scherwindklippen": [time(1,0), time(3,0), time(5,0), time(7,0), time(9,0), time(10,0), time(13,0), time(15,0), time(17,0), time(19,0), time(21,0), time(22,0)]
}

SETTINGS_FILE = "app_settings.json"
OVERLAY_FILE = "overlay_settings.json"

# ---------------- Helfer für Klickdurchlässigkeit -----------------
def make_clickthrough(window):
    hwnd = int(window.winId())
    ex_style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
    ctypes.windll.user32.SetWindowLongW(hwnd, -20, ex_style | 0x80000 | 0x20)

def remove_clickthrough(window):
    hwnd = int(window.winId())
    ex_style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
    ctypes.windll.user32.SetWindowLongW(hwnd, -20, ex_style & ~0x20)

# ------------------ Overlay ------------------
class Overlay(QtWidgets.QWidget):
    EDGE_MARGIN = 8

    def __init__(self, font_size=18, alpha=0.5, save_settings=True):
        super().__init__()
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.resize(350,120)
        self.move(300,200)

        self.movable = False
        self.resize_active = False
        self.dragging = False
        self.resizing = False
        self.resize_dir = None
        self.old_mouse_pos = None
        self.bars = {}
        self.save_settings_flag = save_settings
        self.alpha = alpha

        # Hintergrundwidget
        self.background_widget = QtWidgets.QWidget(self)
        self.background_widget.setGeometry(0,0,self.width(),self.height())
        self.background_widget.setStyleSheet(f"background-color: rgba(0,0,0,{int(self.alpha*255)}); border: none;")

        # Label für Text/Countdown
        self.label = QtWidgets.QLabel(self)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        font = QtGui.QFont("Arial", font_size, QtGui.QFont.Bold)
        self.label.setFont(font)
        self.label.setStyleSheet("color:white; background:transparent;")
        self.label.setGeometry(0,0,self.width(),self.height())

        # Klickdurchlässigkeit
        make_clickthrough(self)

        self.show()
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_overlay)
        self.timer.start(200)

    # ------------------ Move/Resize ------------------
    def set_movable(self, state: bool):
        if state:
            remove_clickthrough(self)
            self.toggle_resize(False)
        self.movable = state
        self.update_overlay_style()

    def toggle_resize(self, state: bool):
        if state:
            remove_clickthrough(self)
            self.set_movable(False)
            self.create_bars()
        else:
            self.hide_bars()
        self.resize_active = state
        self.update_overlay_style()

    def create_bars(self):
        if not self.bars:
            self.bars = {
                "right": QtWidgets.QFrame(self),
                "bottom": QtWidgets.QFrame(self),
                "corner": QtWidgets.QFrame(self)
            }
            for bar in self.bars.values():
                bar.setStyleSheet("background-color: rgba(0,0,255,150);")
        for bar in self.bars.values():
            bar.show()
        self.update_bars_geometry()

    def hide_bars(self):
        for bar in self.bars.values():
            bar.hide()

    def update_bars_geometry(self):
        w, h = self.width(), self.height()
        m = self.EDGE_MARGIN
        self.background_widget.setGeometry(0,0,w,h)
        self.label.setGeometry(0,0,w,h)
        if self.bars:
            self.bars["right"].setGeometry(w-m,0,m,h-m)
            self.bars["bottom"].setGeometry(0,h-m,w-m,m)
            self.bars["corner"].setGeometry(w-m,h-m,m,m)

    def mousePressEvent(self, event):
        self.old_mouse_pos = event.globalPos()
        pos = event.pos()
        w, h = self.width(), self.height()
        m = self.EDGE_MARGIN
        if self.movable:
            self.dragging = True
            self.drag_offset = pos
        elif self.resize_active:
            if pos.x() >= w-m and pos.y() >= h-m:
                self.resizing = True
                self.resize_dir = "SE"
            elif pos.x() >= w-m:
                self.resizing = True
                self.resize_dir = "E"
            elif pos.y() >= h-m:
                self.resizing = True
                self.resize_dir = "S"

    def mouseMoveEvent(self, event):
        pos = event.pos()
        w, h = self.width(), self.height()
        m = self.EDGE_MARGIN

        if self.dragging:
            delta = event.globalPos() - self.old_mouse_pos
            self.move(self.x() + delta.x(), self.y() + delta.y())
            self.old_mouse_pos = event.globalPos()
        elif self.resizing and self.resize_dir:
            delta = event.globalPos() - self.old_mouse_pos
            new_w, new_h = w, h
            if "E" in self.resize_dir:
                new_w += delta.x()
            if "S" in self.resize_dir:
                new_h += delta.y()
            new_w = max(new_w,100)
            new_h = max(new_h,50)
            self.resize(new_w,new_h)
            self.update_bars_geometry()
            self.old_mouse_pos = event.globalPos()
        else:
            if self.resize_active and self.bars:
                if pos.x() >= w-m and pos.y() >= h-m:
                    self.setCursor(QtCore.Qt.SizeFDiagCursor)
                elif pos.x() >= w-m:
                    self.setCursor(QtCore.Qt.SizeHorCursor)
                elif pos.y() >= h-m:
                    self.setCursor(QtCore.Qt.SizeVerCursor)
                else:
                    self.setCursor(QtCore.Qt.ArrowCursor)

    def mouseReleaseEvent(self, event):
        self.dragging = False
        self.resizing = False
        self.resize_dir = None
        self.setCursor(QtCore.Qt.ArrowCursor)
        # Overlay JSON immer speichern
        if self.save_settings_flag:
            self.save_settings()

    # ------------------ Anzeige ------------------
    def update_overlay_style(self, text_color="white"):
        a = int(self.alpha * 255)
        # Hintergrundfarbe grün beim Verschieben, sonst schwarz
        bg_color = f"rgba(0,128,0,{a})" if self.movable else f"rgba(0,0,0,{a})"
        self.background_widget.setStyleSheet(f"background-color:{bg_color};")
        # Schriftfarbe
        self.label.setStyleSheet(f"color:{text_color}; background:transparent;")
        
        # Durchklickbarkeit: Overlay + Hintergrund nur blockierend während Move/Resize
        transparent = not (self.movable or self.resize_active)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, transparent)
        self.background_widget.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, transparent)



    def find_events(self):
        now = datetime.now()
        upcoming_events = []
        recent_events = []

        for name, times in koloss_events.items():
            for t in times:
                event_dt_today = datetime.combine(now.date(), t)
                diff = (now - event_dt_today).total_seconds()
                if 0 <= diff <= 300:
                    recent_events.append((name, event_dt_today))
                event_dt = event_dt_today
                if event_dt < now:
                    event_dt += timedelta(days=1)
                upcoming_events.append((name, event_dt))

        soonest_time = min(evt[1] for evt in upcoming_events)
        due = [evt for evt in upcoming_events if evt[1] == soonest_time]
        return due, soonest_time, recent_events

    def update_overlay(self):
        now = datetime.now()
        due, next_event_time, recent_events = self.find_events()
        if recent_events:
            names = ", ".join([name for name, _ in recent_events])
            countdown = "00:00:00"
            self.update_overlay_style("red")
        else:
            delta = next_event_time - now
            total_seconds = int(delta.total_seconds())
            if total_seconds < 0:
                countdown = "00:00:00"
            else:
                h, rem = divmod(total_seconds,3600)
                m, s = divmod(rem,60)
                countdown = f"{h:02}:{m:02}:{s:02}"
            names = ", ".join([name for name,_ in due])
            self.update_overlay_style("red" if total_seconds<60 else "white")
        self.label.setText(f"{names}\n{countdown}")

    # ------------------ Speichern/Laden ------------------
    def save_settings(self):
        settings = {
            "x": self.x(),
            "y": self.y(),
            "width": self.width(),
            "height": self.height()
        }
        with open(OVERLAY_FILE,"w") as f:
            json.dump(settings,f)

    def load_settings(self, load_json=True):
        if load_json and os.path.exists(OVERLAY_FILE):
            with open(OVERLAY_FILE,"r") as f:
                settings = json.load(f)
                self.resize(settings.get("width",350), settings.get("height",120))
                self.move(settings.get("x",300), settings.get("y",200))
        else:
            self.resize(350,120)
            self.move(300,200)
        self.update_bars_geometry()

class UpdateWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Neue Version V1.2.0")
        self.setFixedSize(350, 220)

        self.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowTitleHint |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.WindowStaysOnTopHint
        )

        label = QtWidgets.QLabel(
            
            """
            <div style="text-align: center;">
                <span style="font-size: 12pt; font-weight: bold;">
                    Neuheiten Version 1.2.0
                </span><br><br><br>
                <span style="font-size: 12pt;">
                    - Durchklickbares Overlay<br><br>
                    - Anpassbare Overlaygröße<br><br>
                    - Speicherbare Overlayeinstellungen<br><br>
                    - Zusätzliche Einstellungen
                </span>
            </div>
            """
        )
        label.setAlignment(QtCore.Qt.AlignCenter)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(label)

        #self.setLayout(layout)


# ------------------ ControlWindow ------------------
class ControlWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Kolossjäger V1.2.0")
        self.resize(450,350)
        self.overlay = None
        self.popup = UpdateWindow()

        main_layout = QtWidgets.QVBoxLayout()
        self.setLayout(main_layout)
        self.tabs = QtWidgets.QTabWidget()
        main_layout.addWidget(self.tabs)

        # Tab Start
        self.tab_start = QtWidgets.QWidget()
        self.tabs.addTab(self.tab_start,"Start")
        layout_start = QtWidgets.QVBoxLayout()
        self.tab_start.setLayout(layout_start)
        layout_start.setAlignment(QtCore.Qt.AlignCenter)
        layout_start.setSpacing(15)

        self.btn_start = QtWidgets.QPushButton("Start Overlay")
        self.btn_move = QtWidgets.QPushButton("Verschieben Overlay")
        self.btn_resize = QtWidgets.QPushButton("Größe ändern")
        self.btn_info = QtWidgets.QPushButton("?")
        self.btn_info.setStyleSheet("font-weight: bold;")
        self.btn_info.setFixedSize(25,25)
        layout_start.addWidget(self.btn_info, alignment=QtCore.Qt.AlignTop | QtCore.Qt.AlignRight)
        for btn in [self.btn_start,self.btn_move,self.btn_resize]:
            btn.setFixedSize(220,60)
            layout_start.addWidget(btn)

        self.btn_start.clicked.connect(self.toggle_overlay)
        self.btn_move.clicked.connect(self.toggle_move)
        self.btn_resize.clicked.connect(self.toggle_resize)
        self.btn_info.clicked.connect(self.info)

        # Tab Einstellungen
        self.tab_settings = QtWidgets.QWidget()
        self.tabs.addTab(self.tab_settings,"Einstellungen")
        layout_settings = QtWidgets.QVBoxLayout()
        self.tab_settings.setLayout(layout_settings)
        layout_settings.addWidget(QtWidgets.QLabel("Schriftgröße Overlay:"))
        self.spin_font = QtWidgets.QSpinBox()
        self.spin_font.setRange(8,50)
        self.spin_font.setValue(18)
        layout_settings.addWidget(self.spin_font)
        self.update = False

        layout_settings.addWidget(QtWidgets.QLabel("Transparenz Overlay:"))
        self.slider_alpha = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_alpha.setRange(0,100)
        self.slider_alpha.setValue(50)
        layout_settings.addWidget(self.slider_alpha)

        self.chk_load_overlay = QtWidgets.QCheckBox("Overlay Einstellungen laden")
        self.chk_load_overlay.setChecked(True)
        layout_settings.addWidget(self.chk_load_overlay)

        self.btn_save_settings = QtWidgets.QPushButton("Einstellungen speichern")
        layout_settings.addWidget(self.btn_save_settings)
        self.btn_save_settings.clicked.connect(self.save_overlay_settings)

        self.load_app_settings()
        if not self.update:
            #print("popup öffnen")
            self.popup.show()

    def info(self):
        self.popup.show()
    # ------------------ Overlay Buttons ------------------
    def toggle_overlay(self):
        if not self.overlay:
            self.overlay = Overlay(font_size=self.spin_font.value(), alpha=self.slider_alpha.value()/100, save_settings=True)
            self.overlay.load_settings(load_json=self.chk_load_overlay.isChecked())
            self.btn_start.setText("Stop Overlay")
        else:
            self.overlay.close()
            self.overlay = None
            self.btn_start.setText("Start Overlay")

    def toggle_move(self):
        if self.overlay:
            if not self.overlay.movable:
                self.overlay.set_movable(True)
                self.overlay.toggle_resize(False)
                self.btn_move.setText("Verschieben beenden")
                self.btn_resize.setText("Größe ändern")
            else:
                self.overlay.set_movable(False)
                self.btn_move.setText("Verschieben Overlay")
            if not self.overlay.resize_active and not self.overlay.movable:
                make_clickthrough(self.overlay)

    def toggle_resize(self):
        if self.overlay:
            if not self.overlay.resize_active:
                self.overlay.toggle_resize(True)
                self.overlay.set_movable(False)
                self.btn_resize.setText("Größe setzen")
                self.btn_move.setText("Verschieben Overlay")
            else:
                self.overlay.toggle_resize(False)
                self.btn_resize.setText("Größe ändern")
            
            if not self.overlay.resize_active and not self.overlay.movable:
                make_clickthrough(self.overlay)

    # ------------------ Einstellungen ------------------
    def save_overlay_settings(self):
        if self.overlay:
            font = self.overlay.label.font()
            font.setPointSize(self.spin_font.value())
            self.overlay.label.setFont(font)
            self.overlay.alpha = self.slider_alpha.value()/100
            self.overlay.update_overlay_style()
        self.save_app_settings()

        # Feedback Knopf
        self.btn_save_settings.setText("Gespeichert")
        QtCore.QTimer.singleShot(1000, lambda: self.btn_save_settings.setText("Einstellungen speichern"))

    def save_app_settings(self):
        settings = {
            "font_size": self.spin_font.value(),
            "overlay_load": self.chk_load_overlay.isChecked(),
            "alpha": self.slider_alpha.value(),
            "update": True
        }
        with open(SETTINGS_FILE,"w") as f:
            json.dump(settings,f)

    def load_app_settings(self):
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE,"r") as f:
                settings = json.load(f)
                self.spin_font.setValue(settings.get("font_size",18))
                self.chk_load_overlay.setChecked(settings.get("overlay_load",True))
                self.slider_alpha.setValue(settings.get("alpha",50))
                self.update = settings.get("update")
        else:
            self.save_app_settings()

    # ------------------ Close ------------------
    def closeEvent(self,event):
        if self.overlay:
            self.overlay.close()
        self.save_app_settings()
        event.accept()

# ------------------ Main ------------------
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = ControlWindow()
    window.show()
    sys.exit(app.exec())
