import sys
import subprocess
from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PySide6 import QtCore, QtWidgets
import requests

VERSION = "1.0.1"

url_check = "https://kabaschlonz.github.io./updater/updates/version.txt"

class UpdateWindow(QWidget):
    def __init__(self, available):
        super().__init__()
        self.available = available

        self.setWindowTitle("Updater")
        self.setGeometry(100, 100, 150, 150)

        self.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowTitleHint |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.WindowStaysOnTopHint
        )

        self.label_update = QtWidgets.QLabel("Update verfügbar\njetzt installieren?")
        self.label_latest = QtWidgets.QLabel("Programm ist aktuell")
        
        layout = QtWidgets.QVBoxLayout(self)

        if self.available:
            self.label_update.setAlignment(QtCore.Qt.AlignCenter) 
            layout.addWidget(self.label_update)

            self.btn_ja = QPushButton("JA")
            self.btn_nein = QPushButton("NEIN")
            layout.addWidget(self.btn_ja)
            layout.addWidget(self.btn_nein)
            self.btn_ja.clicked.connect(self.start_updater)
            self.btn_nein.clicked.connect(self.close)

        else:
            self.label_latest.setAlignment(QtCore.Qt.AlignCenter)
            layout.addWidget(self.label_latest)

            self.btn_okay = QPushButton("OK")
            layout.addWidget(self.btn_okay)
            self.btn_okay.clicked.connect(self.close)

    def start_updater(self):
        subprocess.Popen(["python", "updater.py"])


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Begleiterapp")
        self.setGeometry(100, 100, 300, 200)

        # Button erstellen
        self.btn_objekt1 = QPushButton("Objekt1")
        self.btn_objekt1.clicked.connect(self.start_programm)

        self.btn_update = QPushButton("Update")
        self.btn_update.clicked.connect(self.check_update)

        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.btn_objekt1)
        layout.addWidget(self.btn_update)
        self.setLayout(layout)

    def start_programm(self):
        # anderes Python-Programm starten
        subprocess.Popen(["python", "overlay_v1.2.0.py"])

    def check_update(self):
        # holt info über aktuelle Version
        latest = requests.get(url_check).text.strip()

        # prüft ob Versionen übereinstimmen
        if latest == VERSION:
            self.update_window = UpdateWindow(False)
        else:
            self.update_window = UpdateWindow(True)
        self.update_window.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
